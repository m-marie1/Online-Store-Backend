import Client from '../database';
import { getHashedPassword } from '../utilities/hash_function';

export type User = {
  // id as an optional paramter to test the function without passing the id
  id?: Number;
  first_name: string;
  last_name: string;
  password: string;
};

export class userStore {
  async index(): Promise<User[]> {
    try {
      const conn = await Client.connect();
      const sql = 'SELECT * FROM users';
      const result = await conn.query(sql);
      conn.release();
      return result.rows;
    } catch (err) {
      throw new Error(`couldn't get users ${err}`);
    }
  }

  async show(id: number): Promise<User> {
    try {
      const sql = 'SELECT * FROM users WHERE id=($1)';

      const conn = await Client.connect();

      const result = await conn.query(sql, [id]);

      conn.release();

      return result.rows[0];
    } catch (err) {
      throw new Error(`Could not find user ${id}. Error: ${err}`);
    }
  }

  async create(u: User): Promise<User> {
    try {
      const conn = await Client.connect();
      const sql =
        'INSERT INTO users (first_name, last_name, password) VALUES($1, $2, $3) RETURNING *';

      const hash = getHashedPassword(u.password);

      const result = await conn.query(sql, [u.first_name, u.last_name, hash]);
      const user = result.rows[0];

      conn.release();

      return user;
    } catch (err) {
      throw new Error(
        `unable create user (${u.first_name + u.last_name}): ${err}`
      );
    }
  }
}
